import pygame
pygame.init()
sreen_width = 200

gameWindow = pygame.display.set_mode(())
def plot_snake(gameWindow, color ,snk_list,snake_size):
    if x,y in snk_list:
    pygame.draw.rect(gameWindo, color, [x, y, snake_size, snake_size])

